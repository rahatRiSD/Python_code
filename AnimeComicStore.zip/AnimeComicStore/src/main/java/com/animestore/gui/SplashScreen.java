package com.animestore.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SplashScreen extends JWindow {
    private int progress;
    public SplashScreen(final Runnable done){
        JPanel root=new JPanel(new BorderLayout(0,18)){protected void paintComponent(Graphics g){Graphics2D q=(Graphics2D)g.create();q.setPaint(new GradientPaint(0,0,Theme.PURPLE,getWidth(),getHeight(),Theme.RED));q.fillRect(0,0,getWidth(),getHeight());q.setColor(new Color(255,255,255,28));for(int x=-getHeight();x<getWidth();x+=18)q.drawLine(x,getHeight(),x+getHeight(),0);q.dispose();}};
        root.setBorder(BorderFactory.createEmptyBorder(38,48,34,48)); JLabel logo=new JLabel("OTAKU  NEXUS",SwingConstants.CENTER);logo.setForeground(Color.WHITE);logo.setFont(new Font("SansSerif",Font.BOLD,34));root.add(logo,BorderLayout.CENTER);
        final JProgressBar bar=new JProgressBar(0,100);bar.setStringPainted(true);bar.setForeground(Theme.CYAN);bar.setBackground(Theme.BG);bar.setBorderPainted(false);root.add(bar,BorderLayout.SOUTH);setContentPane(root);setSize(520,280);setLocationRelativeTo(null);
        Timer timer=new Timer(18,null);timer.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){progress+=2;bar.setValue(progress);bar.setString(progress<100?"Loading the multiverse... "+progress+"%":"Ready!");if(progress>=100){((Timer)e.getSource()).stop();dispose();done.run();}}});timer.setInitialDelay(150);timer.start();
    }
}
