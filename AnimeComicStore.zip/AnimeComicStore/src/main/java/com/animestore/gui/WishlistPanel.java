package com.animestore.gui;

import com.animestore.exception.*;
import com.animestore.io.DataStore;
import com.animestore.model.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class WishlistPanel extends StorePanel {
    private final JComboBox<Customer> customer=new JComboBox<Customer>();private final JComboBox<ItemChoice> item=new JComboBox<ItemChoice>();private final WishModel model=new WishModel();private final JTable table=Theme.table(model);
    WishlistPanel(MainFrame f,Store s,DataStore d){super(f,s,d);setLayout(new BorderLayout(0,14));add(Theme.pageHeader("Wishlist","Manage saved items for each customer."),BorderLayout.NORTH);RoundedPanel controls=new RoundedPanel(Theme.PANEL);controls.setLayout(new FlowLayout(FlowLayout.LEFT,10,4));customer.setPreferredSize(new Dimension(240,36));item.setPreferredSize(new Dimension(300,36));controls.add(new JLabel("Customer"));controls.add(customer);controls.add(new JLabel("Item"));controls.add(item);AnimeButton add=new AnimeButton("Add to wishlist",Theme.PURPLE);add.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){addWish();}});controls.add(add);JPanel middle=new JPanel(new BorderLayout(0,14));middle.setOpaque(false);middle.add(controls,BorderLayout.NORTH);middle.add(Theme.scroll(table),BorderLayout.CENTER);add(middle,BorderLayout.CENTER);JPanel actions=new JPanel(new FlowLayout(FlowLayout.LEFT));actions.setOpaque(false);AnimeButton remove=new AnimeButton("Remove selected",Theme.RED);remove.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){removeWish();}});actions.add(remove);add(actions,BorderLayout.SOUTH);customer.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){refreshTable();}});}
    private void addWish(){Customer c=(Customer)customer.getSelectedItem();ItemChoice choice=(ItemChoice)item.getSelectedItem();if(c==null||choice==null){error("Choose both a customer and an item.");return;}c.addToWishlist(choice.item.getItemId());changed("Wishlist updated and saved");}
    private void removeWish(){Customer c=(Customer)customer.getSelectedItem();int r=table.getSelectedRow();if(c==null||r<0){error("Choose a customer and select a wishlist row.");return;}Item i=model.get(r);if(confirm("Remove “"+i.getTitle()+"” from "+c.getName()+"'s wishlist?")){c.removeFromWishlist(i.getItemId());changed("Wishlist updated and saved");}}
    public void refreshData(){Customer selected=(Customer)customer.getSelectedItem();String selectedId=selected==null?null:selected.getCustomerId();customer.removeAllItems();for(Customer c:store.getCustomers()){customer.addItem(c);if(c.getCustomerId().equals(selectedId))customer.setSelectedItem(c);}item.removeAllItems();for(Item i:store.getInventory())item.addItem(new ItemChoice(i));refreshTable();}
    private void refreshTable(){Customer c=(Customer)customer.getSelectedItem();java.util.List<Item> rows=new ArrayList<Item>();if(c!=null)for(String id:c.getWishlist())try{rows.add(store.findItem(id));}catch(ItemNotFoundException ignored){}model.set(rows);}
}
class ItemChoice {final Item item;ItemChoice(Item i){item=i;}public String toString(){return item.getTitle()+" ("+item.getItemId()+") — stock "+item.getStockQty();}}
class WishModel extends AbstractTableModel {private String[] cols={"ID","Title","Type","Price","Stock"};private java.util.List<Item> rows=new ArrayList<Item>();void set(java.util.List<Item> v){rows=v;fireTableDataChanged();}Item get(int r){return rows.get(r);}public int getRowCount(){return rows.size();}public int getColumnCount(){return cols.length;}public String getColumnName(int c){return cols[c];}public Object getValueAt(int r,int c){Item i=rows.get(r);switch(c){case 0:return i.getItemId();case 1:return i.getTitle();case 2:return i.getType();case 3:return i.getPrice();default:return i.getStockQty();}}}
