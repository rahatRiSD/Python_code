package com.animestore.model;

import com.animestore.exception.OutOfStockException;
import java.io.Serializable;

public abstract class Item implements Sellable, Serializable {
    private static final long serialVersionUID = 1L;
    protected String itemId;
    protected String title;
    protected double price;
    protected int stockQty;
    private String imagePath;

    protected Item(String itemId, String title, double price, int stockQty, String imagePath) {
        setItemId(itemId); setTitle(title); setPrice(price); setStockQty(stockQty); setImagePath(imagePath);
    }
    public String getItemId() { return itemId; }
    public void setItemId(String value) { itemId = required(value, "Item ID"); }
    public String getTitle() { return title; }
    public void setTitle(String value) { title = required(value, "Title"); }
    public double getPrice() { return price; }
    public void setPrice(double value) {
        if (value < 0 || Double.isNaN(value) || Double.isInfinite(value)) throw new IllegalArgumentException("Price must be a valid non-negative number.");
        price = value;
    }
    public int getStockQty() { return stockQty; }
    public void setStockQty(int value) {
        if (value < 0) throw new IllegalArgumentException("Stock quantity cannot be negative.");
        stockQty = value;
    }
    public String getImagePath() { return imagePath; }
    public void setImagePath(String value) { imagePath = value == null || value.trim().isEmpty() ? "assets/covers/" + itemId + ".png" : value.trim(); }
    @Override public void sell() throws OutOfStockException {
        if (stockQty <= 0) throw new OutOfStockException(title + " is out of stock.");
        stockQty--;
    }
    public abstract String getDetails();
    public abstract String getType();
    protected static String required(String value, String field) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(field + " is required.");
        return value.trim();
    }
}
