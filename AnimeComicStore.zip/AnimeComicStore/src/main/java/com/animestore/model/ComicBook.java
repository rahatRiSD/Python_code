package com.animestore.model;

public class ComicBook extends Item {
    private static final long serialVersionUID = 1L;
    private String publisher; private int issueNumber; private String writer;
    public ComicBook(String id, String title, double price, int stock, String publisher, int issue, String writer, String imagePath) {
        super(id, title, price, stock, imagePath); setPublisher(publisher); setIssueNumber(issue); setWriter(writer);
    }
    public String getPublisher() { return publisher; }
    public void setPublisher(String value) { publisher = required(value, "Publisher"); }
    public int getIssueNumber() { return issueNumber; }
    public void setIssueNumber(int value) { if (value <= 0) throw new IllegalArgumentException("Issue number must be positive."); issueNumber = value; }
    public String getWriter() { return writer; }
    public void setWriter(String value) { writer = required(value, "Writer"); }
    @Override public String getDetails() { return "Publisher: " + publisher + " | Issue: #" + issueNumber + " | Writer: " + writer; }
    @Override public String getType() { return "ComicBook"; }
}
