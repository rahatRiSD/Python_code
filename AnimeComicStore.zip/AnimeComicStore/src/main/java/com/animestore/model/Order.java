package com.animestore.model;

import com.animestore.exception.InvalidOperationException;
import com.animestore.exception.ItemNotFoundException;
import com.animestore.exception.OutOfStockException;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Order implements Serializable {
    private static final long serialVersionUID = 1L;
    private String orderId; private LocalDate orderDate; private double totalAmount; private String status;
    private String customerId; private String staffId; private final List<OrderItem> lineItems = new ArrayList<OrderItem>();
    public Order(String id, LocalDate date, String customerId, String staffId) {
        setOrderId(id); setOrderDate(date); setCustomerId(customerId); setStaffId(staffId); status = "Draft";
    }
    public String getOrderId() { return orderId; }
    public void setOrderId(String v) { orderId = required(v, "Order ID"); }
    public LocalDate getOrderDate() { return orderDate; }
    public void setOrderDate(LocalDate v) { if (v == null) throw new IllegalArgumentException("Order date is required."); orderDate = v; }
    public double getTotalAmount() { return totalAmount; }
    public String getStatus() { return status; }
    public void setStatus(String v) { status = required(v, "Status"); }
    public String getCustomerId() { return customerId; }
    public void setCustomerId(String v) { customerId = required(v, "Customer"); }
    public String getStaffId() { return staffId; }
    public void setStaffId(String v) { staffId = required(v, "Staff"); }
    public List<OrderItem> getLineItems() { return new ArrayList<OrderItem>(lineItems); }
    public void addLineItem(OrderItem item) { if ("Placed".equals(status)) throw new IllegalStateException("A placed order cannot be changed."); lineItems.add(item); calculateTotal(); }
    public void clearLineItems() { lineItems.clear(); calculateTotal(); }
    public double calculateTotal() { totalAmount = 0; for (OrderItem i : lineItems) totalAmount += i.getSubtotal(); return totalAmount; }
    public void placeOrder(Store store) throws ItemNotFoundException, OutOfStockException, InvalidOperationException {
        if (!"Draft".equals(status)) throw new InvalidOperationException("Only draft orders can be placed.");
        if (lineItems.isEmpty()) throw new InvalidOperationException("Add at least one item before placing the order.");
        Map<String,Integer> requested = new LinkedHashMap<String,Integer>();
        for (OrderItem line : lineItems) requested.put(line.getItemId(), (requested.containsKey(line.getItemId()) ? requested.get(line.getItemId()) : 0) + line.getQuantity());
        for (Map.Entry<String,Integer> entry : requested.entrySet()) {
            Item item = store.findItem(entry.getKey());
            if (item.getStockQty() < entry.getValue()) throw new OutOfStockException(item.getTitle() + " has only " + item.getStockQty() + " in stock; " + entry.getValue() + " requested.");
        }
        for (Map.Entry<String,Integer> entry : requested.entrySet()) {
            Item item = store.findItem(entry.getKey());
            for (int i = 0; i < entry.getValue(); i++) item.sell();
        }
        status = "Placed"; calculateTotal();
    }
    public void cancelOrder(Store store) throws InvalidOperationException, ItemNotFoundException {
        if ("Cancelled".equals(status)) throw new InvalidOperationException("Order is already cancelled.");
        if ("Placed".equals(status)) for (OrderItem line : lineItems) {
            Item item = store.findItem(line.getItemId()); item.setStockQty(item.getStockQty() + line.getQuantity());
        }
        status = "Cancelled";
    }
    private static String required(String v, String f) { if (v == null || v.trim().isEmpty()) throw new IllegalArgumentException(f + " is required."); return v.trim(); }
}
