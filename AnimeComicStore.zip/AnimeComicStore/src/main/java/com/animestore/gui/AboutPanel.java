package com.animestore.gui;

import com.animestore.io.DataStore;
import com.animestore.model.Store;
import javax.swing.*;
import java.awt.*;

public class AboutPanel extends StorePanel {
    AboutPanel(MainFrame f,Store s,DataStore d){super(f,s,d);setLayout(new BorderLayout(0,16));add(Theme.pageHeader("About & OOP Concepts","A living map from the course rubric to this application."),BorderLayout.NORTH);
        JPanel grid=new JPanel(new GridLayout(2,2,16,16));grid.setOpaque(false);grid.add(card("ENCAPSULATION","All model state is private/protected and accessed through validated getters and setters. Negative prices, stock and quantities are rejected."));grid.add(card("INHERITANCE","Anime, ComicBook and Merchandise extend the abstract Item superclass and reuse its identity, title, price and stock behavior."));grid.add(card("ABSTRACTION","Item is abstract and declares getDetails()/getType(). Sellable is an interface; Item implements it through the checked OutOfStockException contract."));grid.add(card("POLYMORPHISM","Inventory is one List<Item>. The inventory GUI iterates over it and calls getType(), getDetails() and sell() on different subclasses through Item references."));
        JPanel content=new JPanel(new BorderLayout(0,16));content.setOpaque(false);content.add(grid,BorderLayout.CENTER);content.add(card("RUBRIC COVERAGE","Full Insert / Update / Get / Delete is available for Item, Customer, Staff and Order. Data auto-loads at startup and auto-saves after every change and on exit. Four checked custom exceptions are caught by the GUI. CardLayout navigation, responsive layout managers, tables, validation, confirmations, cover thumbnails and non-blocking Swing Timer animations complete the management page."),BorderLayout.SOUTH);add(content,BorderLayout.CENTER);}
    private JPanel card(String title,String text){RoundedPanel p=new RoundedPanel(Theme.PANEL);p.setLayout(new BorderLayout(0,8));JLabel h=new JLabel(title);h.setForeground(Theme.RED);h.setFont(new Font("SansSerif",Font.BOLD,14));JTextArea body=new JTextArea(text);body.setEditable(false);body.setLineWrap(true);body.setWrapStyleWord(true);body.setFont(new Font("SansSerif",Font.PLAIN,14));body.setOpaque(false);body.setForeground(Theme.TEXT);p.add(h,BorderLayout.NORTH);p.add(body,BorderLayout.CENTER);return p;}
    public void refreshData(){}
}
