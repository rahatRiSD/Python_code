# Custom cover images

Drop PNG cover art in this folder using an item's ID as the filename, for example `A001.png`, `C001.png`, or `M001.png`.

The application automatically looks for `assets/covers/<itemId>.png`. A selected custom path can also be saved from the Inventory form. If an image is absent or unreadable, the GUI draws a category-colored original placeholder, so a missing image never crashes the application.
