# Otaku Nexus — Anime & Comic Book Store Management System

A complete Java 8-compatible Swing desktop application for an OOP1 lab performance evaluation. It uses only the JDK: no external JAR is required. The interface uses a deep navy anime/comic theme, responsive layout managers, custom-painted rounded components, thumbnails, hover effects and non-blocking animations.

## Run with plain Java

From the `AnimeComicStore` folder:

```bash
mkdir -p out
find src/main/java -name "*.java" -print0 | xargs -0 javac -encoding UTF-8 -d out
java -cp out com.animestore.app.Main
```

Windows PowerShell:

```powershell
New-Item -ItemType Directory -Force out
$sources = Get-ChildItem -Recurse src/main/java -Filter *.java | ForEach-Object FullName
javac -encoding UTF-8 -d out $sources
java -cp out com.animestore.app.Main
```

## Run with Maven

```bash
mvn clean package
java -jar target/anime-comic-store-1.0.0.jar
```

The Maven build also uses only the JDK and deliberately avoids FlatLaf, so the submission remains portable on laboratory computers. The polished look is implemented by project-owned Swing painting code.

## Verify the model and persistence

```bash
mkdir -p out-test
find src/main/java src/test/java -name "*.java" -print0 | xargs -0 javac -encoding UTF-8 -d out-test
java -cp out-test com.animestore.ModelPersistenceSmokeTest
```

## Package structure

```text
AnimeComicStore/
├── pom.xml
├── README.md
├── assets/covers/                 custom PNG covers named by item ID
├── data/                          generated automatically at runtime
├── src/main/java/com/animestore/
│   ├── app/Main.java
│   ├── exception/
│   │   ├── CustomerNotFoundException.java
│   │   ├── InvalidOperationException.java
│   │   ├── ItemNotFoundException.java
│   │   └── OutOfStockException.java
│   ├── io/DataStore.java
│   ├── model/
│   │   ├── Anime.java, ComicBook.java, Merchandise.java
│   │   ├── Item.java, Sellable.java
│   │   ├── Customer.java, Staff.java
│   │   ├── Order.java, OrderItem.java, Store.java
│   └── gui/
│       ├── MainFrame.java, SplashScreen.java
│       ├── AnimatedPanelSwitcher.java, Theme.java, StorePanel.java
│       ├── DashboardPanel.java, InventoryPanel.java
│       ├── CustomerPanel.java, StaffPanel.java
│       ├── OrderPanel.java, WishlistPanel.java, AboutPanel.java
└── src/test/java/com/animestore/ModelPersistenceSmokeTest.java
```

## Rubric and OOP mapping

- **Encapsulation:** All state is private or protected. Public setters validate required text and reject negative price/stock or invalid quantities.
- **Inheritance:** `Anime`, `ComicBook`, and `Merchandise` extend `Item`.
- **Abstraction:** `Item` is abstract; `Sellable` is an interface. Concrete item classes supply their own details and category.
- **Polymorphism:** `Store` owns one `List<Item>`. `InventoryPanel` renders every subtype through `Item.getType()` and `Item.getDetails()`. `Order` sells through the common item contract.
- **Full CRUD:** Inventory, Customers, Staff, and Orders each provide Insert, Update, Get/search/view, and Delete in the GUI. Delete operations ask for confirmation and enforce referential/stock integrity.
- **Checked exceptions:** Four checked domain exceptions are raised by model operations and caught as friendly GUI dialogs. No stack trace is shown to the user.
- **File I/O:** `DataStore` keeps `items.dat`, `customers.dat`, `staff.dat`, and `orders.dat`. It auto-loads at startup, auto-saves after each successful mutation, and saves on exit.
- **Data integrity:** Every save writes a temporary file, flushes/closes it, keeps a `.bak` copy, then performs atomic replacement when supported. Corrupt data can fall back to the last good backup. Order stock is validated as a complete transaction before any units are removed.
- **GUI management page:** One `JFrame` contains CardLayout-based screens, reusable transitions, dashboard statistics, responsive layout managers and searchable tables.

The in-app **About / OOP** screen repeats this mapping for a live viva demonstration.

## GUI and animation highlights

- Approximately 1.5-second animated splash screen.
- Fade-in transitions between CardLayout screens.
- Animated sidebar hover/selection colors.
- Dashboard counters animate to current totals.
- Successful actions show a fading green confirmation toast.
- Inventory cover thumbnails use custom files or safe generated placeholders.
- Category-colored type labels and red/orange low-stock warnings.
- Multi-item order builder with quantity validation and a live total.

All animations use `javax.swing.Timer`; the Event Dispatch Thread is never blocked with `Thread.sleep`.

## First-run data and storage

On the first launch, the application seeds six original fictional products, two customers and two staff members, then writes them to the `data` folder. Run the application from the project folder so `data/` and `assets/covers/` resolve there. To use a different data location, launch with:

```bash
java -Danimestore.data=/absolute/path/to/data -cp out com.animestore.app.Main
```

To reset only the application's records, close the application, back up the `data` folder, and remove its four `.dat` files. The next launch recreates seed data.

## Custom covers

Add a PNG named after the item ID under `assets/covers` (for example, `A001.png`) or select an image path in the Inventory Add/Edit form. Missing and invalid images fall back to original category-colored placeholders.
