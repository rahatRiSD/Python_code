package com.animestore.gui;

import com.animestore.io.DataStore;
import com.animestore.model.Store;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.IOException;

abstract class StorePanel extends JPanel {
    protected final MainFrame frame; protected final Store store; protected final DataStore dataStore;
    StorePanel(MainFrame frame, Store store, DataStore dataStore){this.frame=frame;this.store=store;this.dataStore=dataStore;setOpaque(false);setBorder(new EmptyBorder(20,24,24,24));}
    protected void changed(String message){try{dataStore.saveAll(store);frame.refreshAll();frame.showToast(message);}catch(IOException e){error("Your change is in memory, but saving failed.\n"+e.getMessage());}}
    protected void error(String message){JOptionPane.showMessageDialog(frame,message,"Could not complete action",JOptionPane.ERROR_MESSAGE);}
    protected boolean confirm(String message){return JOptionPane.showConfirmDialog(frame,message,"Please confirm",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE)==JOptionPane.YES_OPTION;}
    protected String prompt(String message,String initial){return (String)JOptionPane.showInputDialog(frame,message,"Enter value",JOptionPane.PLAIN_MESSAGE,null,null,initial);}
    public abstract void refreshData();
}
