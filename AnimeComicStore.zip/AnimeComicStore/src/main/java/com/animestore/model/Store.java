package com.animestore.model;

import com.animestore.exception.CustomerNotFoundException;
import com.animestore.exception.InvalidOperationException;
import com.animestore.exception.ItemNotFoundException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Store implements Serializable {
    private static final long serialVersionUID = 1L;
    private String storeName; private String location;
    private List<Item> inventory = new ArrayList<Item>(); private List<Customer> customers = new ArrayList<Customer>();
    private List<Staff> staff = new ArrayList<Staff>(); private List<Order> orders = new ArrayList<Order>();
    public Store(String name, String location) { setStoreName(name); setLocation(location); }
    public String getStoreName() { return storeName; }
    public void setStoreName(String v) { storeName = required(v, "Store name"); }
    public String getLocation() { return location; }
    public void setLocation(String v) { location = required(v, "Location"); }
    public List<Item> getInventory() { return inventory; }
    public List<Customer> getCustomers() { return customers; }
    public List<Staff> getStaff() { return staff; }
    public List<Order> getOrders() { return orders; }
    public void replaceData(List<Item> i, List<Customer> c, List<Staff> s, List<Order> o) { inventory=i; customers=c; staff=s; orders=o; }
    public void addItem(Item item) throws InvalidOperationException { if (hasItem(item.getItemId())) throw new InvalidOperationException("Item ID already exists."); inventory.add(item); }
    public void addCustomer(Customer c) throws InvalidOperationException { if (hasCustomer(c.getCustomerId())) throw new InvalidOperationException("Customer ID already exists."); customers.add(c); }
    public void addStaff(Staff s) throws InvalidOperationException { if (findStaffOrNull(s.getStaffId()) != null) throw new InvalidOperationException("Staff ID already exists."); staff.add(s); }
    public void addOrder(Order o) throws InvalidOperationException { if (findOrderOrNull(o.getOrderId()) != null) throw new InvalidOperationException("Order ID already exists."); orders.add(o); }
    public Item findItem(String id) throws ItemNotFoundException { for (Item i:inventory) if(i.getItemId().equalsIgnoreCase(id)) return i; throw new ItemNotFoundException("Item " + id + " was not found."); }
    public Customer findCustomer(String id) throws CustomerNotFoundException { for(Customer c:customers) if(c.getCustomerId().equalsIgnoreCase(id)) return c; throw new CustomerNotFoundException("Customer " + id + " was not found."); }
    public Staff findStaff(String id) throws InvalidOperationException { Staff s=findStaffOrNull(id); if(s==null) throw new InvalidOperationException("Staff " + id + " was not found."); return s; }
    public Order findOrder(String id) throws InvalidOperationException { Order o=findOrderOrNull(id); if(o==null) throw new InvalidOperationException("Order " + id + " was not found."); return o; }
    public void removeItem(String id) throws ItemNotFoundException { inventory.remove(findItem(id)); for(Customer c:customers)c.removeFromWishlist(id); }
    public void removeCustomer(String id) throws CustomerNotFoundException { customers.remove(findCustomer(id)); }
    public void removeStaff(String id) throws InvalidOperationException { staff.remove(findStaff(id)); }
    public void removeOrder(String id) throws InvalidOperationException { Order o=findOrder(id); orders.remove(o); for(Customer c:customers)c.removeOrderFromHistory(id); }
    public double getRevenue() { double n=0; for(Order o:orders) if("Placed".equals(o.getStatus())) n+=o.getTotalAmount(); return n; }
    private boolean hasItem(String id){try{findItem(id);return true;}catch(ItemNotFoundException e){return false;}}
    private boolean hasCustomer(String id){try{findCustomer(id);return true;}catch(CustomerNotFoundException e){return false;}}
    private Staff findStaffOrNull(String id){for(Staff s:staff)if(s.getStaffId().equalsIgnoreCase(id))return s;return null;}
    private Order findOrderOrNull(String id){for(Order o:orders)if(o.getOrderId().equalsIgnoreCase(id))return o;return null;}
    private static String required(String v,String f){if(v==null||v.trim().isEmpty())throw new IllegalArgumentException(f+" is required.");return v.trim();}
}
