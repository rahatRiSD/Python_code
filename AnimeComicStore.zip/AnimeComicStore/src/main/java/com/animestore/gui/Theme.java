package com.animestore.gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

public final class Theme {
    public static final Color BG = new Color(13, 17, 34), PANEL = new Color(24, 30, 55), PANEL_2 = new Color(32, 39, 70);
    public static final Color RED = new Color(255, 72, 88), PURPLE = new Color(145, 92, 255), ORANGE = new Color(255, 158, 67);
    public static final Color CYAN = new Color(45, 212, 191), TEXT = new Color(241, 245, 255), MUTED = new Color(161, 170, 198);
    private Theme() { }
    public static void install() {
        UIManager.put("Panel.background", BG); UIManager.put("Label.foreground", TEXT);
        UIManager.put("Table.background", PANEL); UIManager.put("Table.foreground", TEXT); UIManager.put("Table.gridColor", new Color(55, 64, 96));
        UIManager.put("Table.selectionBackground", new Color(92, 62, 150)); UIManager.put("Table.selectionForeground", Color.WHITE);
        UIManager.put("TableHeader.background", PANEL_2); UIManager.put("TableHeader.foreground", TEXT);
        UIManager.put("TextField.background", PANEL_2); UIManager.put("TextField.foreground", TEXT); UIManager.put("TextField.caretForeground", TEXT);
        UIManager.put("ComboBox.background", PANEL_2); UIManager.put("ComboBox.foreground", TEXT);
        UIManager.put("TextArea.background", PANEL_2); UIManager.put("TextArea.foreground", TEXT);
        UIManager.put("OptionPane.background", PANEL); UIManager.put("OptionPane.messageForeground", TEXT);
        UIManager.put("ScrollPane.background", PANEL); UIManager.put("Viewport.background", PANEL);
    }
    public static JLabel title(String text) { JLabel l=new JLabel(text); l.setFont(new Font("SansSerif",Font.BOLD,25)); l.setForeground(TEXT); return l; }
    public static JLabel muted(String text) { JLabel l=new JLabel(text); l.setForeground(MUTED); return l; }
    public static JPanel pageHeader(String title, String subtitle) {
        JPanel p=new JPanel(); p.setOpaque(false); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS)); p.setBorder(new EmptyBorder(4,4,18,4));
        p.add(title(title)); p.add(Box.createVerticalStrut(4)); p.add(muted(subtitle)); return p;
    }
    public static JScrollPane scroll(Component c) { JScrollPane s=new JScrollPane(c); s.setBorder(BorderFactory.createLineBorder(new Color(58,67,100))); s.getViewport().setBackground(PANEL); return s; }
    public static JTable table(javax.swing.table.TableModel m) { JTable t=new JTable(m); t.setRowHeight(52); t.setShowVerticalLines(false); t.setIntercellSpacing(new Dimension(0,1)); t.getTableHeader().setPreferredSize(new Dimension(0,38)); t.setFillsViewportHeight(true); return t; }
}

class RoundedPanel extends JPanel {
    private final Color fill; RoundedPanel(Color fill){this.fill=fill;setOpaque(false);setBorder(new EmptyBorder(14,14,14,14));}
    @Override protected void paintComponent(Graphics g){Graphics2D g2=(Graphics2D)g.create();g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g2.setColor(fill);g2.fill(new RoundRectangle2D.Double(0,0,getWidth()-1,getHeight()-1,20,20));g2.dispose();super.paintComponent(g);}
}

class AnimeButton extends JButton {
    private Color current, target; private final Color base;
    AnimeButton(String text, Color color){super(text);base=color;current=color;target=color;setForeground(Color.WHITE);setFont(new Font("SansSerif",Font.BOLD,13));setBorder(new EmptyBorder(10,16,10,16));setContentAreaFilled(false);setFocusPainted(false);setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        final Timer timer=new Timer(16,new ActionListener(){public void actionPerformed(ActionEvent e){current=mix(current,target,.22f);repaint();if(close(current,target))((Timer)e.getSource()).stop();}});
        addMouseListener(new MouseAdapter(){public void mouseEntered(MouseEvent e){target=base.brighter();timer.start();}public void mouseExited(MouseEvent e){target=base;timer.start();}});
    }
    void setActive(boolean active){target=active?Theme.PURPLE:base;current=target;repaint();}
    @Override protected void paintComponent(Graphics g){Graphics2D g2=(Graphics2D)g.create();g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g2.setColor(current);g2.fillRoundRect(0,0,getWidth(),getHeight(),16,16);g2.dispose();super.paintComponent(g);}
    private static Color mix(Color a,Color b,float p){return new Color((int)(a.getRed()+(b.getRed()-a.getRed())*p),(int)(a.getGreen()+(b.getGreen()-a.getGreen())*p),(int)(a.getBlue()+(b.getBlue()-a.getBlue())*p));}
    private static boolean close(Color a,Color b){return Math.abs(a.getRed()-b.getRed())<2&&Math.abs(a.getGreen()-b.getGreen())<2&&Math.abs(a.getBlue()-b.getBlue())<2;}
}

class CoverIcon implements Icon {
    private final String type,title,path; private final int w,h;
    CoverIcon(String type,String title,String path,int w,int h){this.type=type;this.title=title;this.path=path;this.w=w;this.h=h;}
    public int getIconWidth(){return w;} public int getIconHeight(){return h;}
    public void paintIcon(Component c,Graphics g,int x,int y){
        if(path!=null&&!path.trim().isEmpty()){ImageIcon icon=new ImageIcon(path);if(icon.getIconWidth()>0){g.drawImage(icon.getImage(),x,y,w,h,c);return;}}
        Graphics2D q=(Graphics2D)g.create();q.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        Color a="Anime".equals(type)?Theme.PURPLE:("ComicBook".equals(type)?Theme.RED:Theme.ORANGE);q.setPaint(new GradientPaint(x,y,a,x+w,y+h,Theme.BG));q.fillRoundRect(x,y,w,h,12,12);
        q.setColor(new Color(255,255,255,55));for(int i=-h;i<w;i+=8)q.drawLine(x+i,y+h,x+i+h,y);
        q.setColor(Color.WHITE);q.setFont(new Font("SansSerif",Font.BOLD,Math.max(9,w/7)));String tag="Anime".equals(type)?"ANIME":("ComicBook".equals(type)?"COMIC":"MERCH");q.drawString(tag,x+5,y+15);
        q.setFont(new Font("SansSerif",Font.BOLD,Math.max(10,w/6)));String initial=title==null?"?":title.substring(0,1).toUpperCase();q.drawString(initial,x+w/2-4,y+h/2+7);q.dispose();
    }
}
