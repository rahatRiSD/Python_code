package com.animestore.app;

import com.animestore.gui.*;
import com.animestore.io.DataStore;
import com.animestore.model.Store;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable(){public void run(){Theme.install();final DataStore dataStore=new DataStore();final Store store=dataStore.load();SplashScreen splash=new SplashScreen(new Runnable(){public void run(){new MainFrame(store,dataStore).setVisible(true);}});splash.setVisible(true);}});
    }
}
