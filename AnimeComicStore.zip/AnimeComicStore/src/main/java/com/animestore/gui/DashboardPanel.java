package com.animestore.gui;

import com.animestore.io.DataStore;
import com.animestore.model.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;

public class DashboardPanel extends StorePanel {
    private final StatCard items=new StatCard("ITEMS",Theme.PURPLE),customers=new StatCard("CUSTOMERS",Theme.RED),staff=new StatCard("STAFF",Theme.ORANGE),orders=new StatCard("ORDERS",Theme.CYAN),revenue=new StatCard("REVENUE (৳)",new Color(52,211,153));
    DashboardPanel(MainFrame f,Store s,DataStore d){super(f,s,d);setLayout(new BorderLayout(0,20));
        RoundedPanel hero=new RoundedPanel(Theme.PANEL);hero.setLayout(new BorderLayout());JPanel copy=new JPanel();copy.setOpaque(false);copy.setLayout(new BoxLayout(copy,BoxLayout.Y_AXIS));JLabel kicker=new JLabel("ANIME • COMICS • COLLECTIBLES");kicker.setForeground(Theme.RED);kicker.setFont(new Font("SansSerif",Font.BOLD,11));copy.add(kicker);copy.add(Box.createVerticalStrut(8));JLabel h=new JLabel("Welcome to Otaku Nexus");h.setFont(new Font("SansSerif",Font.BOLD,30));h.setForeground(Color.WHITE);copy.add(h);copy.add(Box.createVerticalStrut(6));copy.add(Theme.muted("A polished command center for inventory, customers, staff, orders and wishlists."));hero.add(copy,BorderLayout.CENTER);JLabel emblem=new JLabel(new CoverIcon("Anime","Nexus","",110,110));hero.add(emblem,BorderLayout.EAST);add(hero,BorderLayout.NORTH);
        JPanel center=new JPanel(new BorderLayout(0,18));center.setOpaque(false);JPanel stats=new JPanel(new GridLayout(1,5,14,0));stats.setOpaque(false);stats.add(items);stats.add(customers);stats.add(staff);stats.add(orders);stats.add(revenue);center.add(stats,BorderLayout.NORTH);
        RoundedPanel activity=new RoundedPanel(Theme.PANEL);activity.setLayout(new BorderLayout(0,12));activity.add(Theme.title("Store pulse"),BorderLayout.NORTH);JTextArea info=new JTextArea();info.setEditable(false);info.setLineWrap(true);info.setWrapStyleWord(true);info.setFont(new Font("SansSerif",Font.PLAIN,15));info.setBorder(new EmptyBorder(8,4,8,4));info.setText("Low-stock items are highlighted in Inventory. Create multi-item orders in Orders, explore each customer's history in Customers, and manage saved favorites in Wishlist. Every successful change is saved immediately using atomic file replacement and a backup copy.");activity.add(info,BorderLayout.CENTER);center.add(activity,BorderLayout.CENTER);add(center,BorderLayout.CENTER);}
    public void refreshData(){items.animateTo(store.getInventory().size());customers.animateTo(store.getCustomers().size());staff.animateTo(store.getStaff().size());orders.animateTo(store.getOrders().size());revenue.animateTo((int)Math.round(store.getRevenue()));}
}

class StatCard extends RoundedPanel {
    private final JLabel value=new JLabel("0"),label=new JLabel(); private Timer timer; private int current;
    StatCard(String name,Color color){super(Theme.PANEL);setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));JLabel dot=new JLabel("●");dot.setForeground(color);dot.setFont(new Font("SansSerif",Font.BOLD,18));value.setForeground(Color.WHITE);value.setFont(new Font("SansSerif",Font.BOLD,27));label.setText(name);label.setForeground(Theme.MUTED);label.setFont(new Font("SansSerif",Font.BOLD,10));add(dot);add(Box.createVerticalStrut(6));add(value);add(label);}
    void animateTo(final int target){if(timer!=null)timer.stop();timer=new Timer(22,new ActionListener(){public void actionPerformed(ActionEvent e){int diff=target-current;if(diff==0){((Timer)e.getSource()).stop();return;}current+=diff>0?Math.max(1,diff/8):Math.min(-1,diff/8);value.setText(String.valueOf(current));}});timer.start();}
}
