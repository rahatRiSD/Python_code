package com.animestore.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AnimatedPanelSwitcher extends JPanel {
    private final CardLayout cards = new CardLayout(); private float alpha=1f; private String current;
    public AnimatedPanelSwitcher(){setLayout(cards);setOpaque(false);}
    public void addScreen(String name,JComponent component){add(component,name);if(current==null)current=name;}
    public void showScreen(final String name){if(name.equals(current))return;alpha=0f;cards.show(this,name);current=name;
        Timer timer=new Timer(16,null);timer.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){alpha=Math.min(1f,alpha+.09f);repaint();if(alpha>=1f)((Timer)e.getSource()).stop();}});timer.start();
    }
    @Override public void paint(Graphics g){Graphics2D g2=(Graphics2D)g.create();g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,alpha));super.paint(g2);g2.dispose();}
}
