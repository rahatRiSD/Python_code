package com.animestore.model;

import java.io.Serializable;

public class Staff implements Serializable {
    private static final long serialVersionUID = 1L;
    private String staffId; private String name; private String role;
    public Staff(String id, String name, String role) { setStaffId(id); setName(name); setRole(role); }
    public String getStaffId() { return staffId; }
    public void setStaffId(String v) { staffId = required(v, "Staff ID"); }
    public String getName() { return name; }
    public void setName(String v) { name = required(v, "Staff name"); }
    public String getRole() { return role; }
    public void setRole(String v) { role = required(v, "Role"); }
    public String manageInventory() { return name + " is managing inventory."; }
    public String processOrder() { return name + " is processing an order."; }
    private static String required(String v, String f) { if (v == null || v.trim().isEmpty()) throw new IllegalArgumentException(f + " is required."); return v.trim(); }
    @Override public String toString() { return name + " (" + staffId + ")"; }
}
