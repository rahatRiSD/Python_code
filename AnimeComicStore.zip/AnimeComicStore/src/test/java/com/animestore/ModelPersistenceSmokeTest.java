package com.animestore;

import com.animestore.exception.*;
import com.animestore.io.DataStore;
import com.animestore.model.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;

public class ModelPersistenceSmokeTest {
    public static void main(String[] args) throws Exception {
        Path dir=Files.createTempDirectory("anime-store-test-");DataStore files=new DataStore(dir);Store store=files.load();
        check(store.getInventory().size()>=6,"seed inventory");check(store.getCustomers().size()==2,"seed customers");
        Item item=store.findItem("A001");int before=item.getStockQty();Order ok=new Order("TEST-1",LocalDate.now(),"CU001","ST001");ok.addLineItem(new OrderItem("A001",item.getTitle(),2,item.getPrice()));ok.placeOrder(store);store.addOrder(ok);store.findCustomer("CU001").purchaseItem(ok.getOrderId());check(item.getStockQty()==before-2,"placing decrements stock");
        ok.cancelOrder(store);check(item.getStockQty()==before,"cancelling restores stock");
        Order tooMany=new Order("TEST-2",LocalDate.now(),"CU001","ST001");tooMany.addLineItem(new OrderItem("A001",item.getTitle(),before,item.getPrice()));tooMany.addLineItem(new OrderItem("A001",item.getTitle(),1,item.getPrice()));try{tooMany.placeOrder(store);throw new AssertionError("Expected OutOfStockException");}catch(OutOfStockException expected){}check(item.getStockQty()==before,"failed order is transactional");
        files.saveAll(store);Store loaded=files.load();check(loaded.findOrder("TEST-1").getStatus().equals("Cancelled"),"order persistence");check(loaded.findItem("A001").getStockQty()==before,"stock persistence");
        System.out.println("PASS: model, exceptions, transaction safety and file persistence");
    }
    private static void check(boolean value,String label){if(!value)throw new AssertionError("Failed: "+label);}
}
