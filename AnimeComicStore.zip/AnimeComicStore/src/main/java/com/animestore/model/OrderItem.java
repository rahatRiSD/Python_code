package com.animestore.model;

import java.io.Serializable;

public class OrderItem implements Serializable {
    private static final long serialVersionUID = 1L;
    private final String itemId; private final String itemTitle; private final int quantity; private final double unitPrice;
    public OrderItem(String itemId, String itemTitle, int quantity, double unitPrice) {
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be positive.");
        this.itemId = itemId; this.itemTitle = itemTitle; this.quantity = quantity; this.unitPrice = unitPrice;
    }
    public String getItemId() { return itemId; }
    public String getItemTitle() { return itemTitle; }
    public int getQuantity() { return quantity; }
    public double getUnitPrice() { return unitPrice; }
    public double getSubtotal() { return quantity * unitPrice; }
}
