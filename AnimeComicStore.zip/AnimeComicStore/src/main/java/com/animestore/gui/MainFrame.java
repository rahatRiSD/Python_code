package com.animestore.gui;

import com.animestore.io.DataStore;
import com.animestore.model.Store;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainFrame extends JFrame {
    private final Store store; private final DataStore dataStore; private final AnimatedPanelSwitcher switcher=new AnimatedPanelSwitcher();
    private final java.util.List<StorePanel> panels=new ArrayList<StorePanel>(); private final Map<String,AnimeButton> nav=new LinkedHashMap<String,AnimeButton>();
    private final ToastGlass toast=new ToastGlass();
    public MainFrame(Store store,DataStore dataStore){
        super("Otaku Nexus — Anime & Comic Book Store Management System");this.store=store;this.dataStore=dataStore;
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);setMinimumSize(new Dimension(1080,700));setSize(1380,840);setLocationRelativeTo(null);setIconImage(createAppIcon());
        JPanel root=new JPanel(new BorderLayout()){protected void paintComponent(Graphics g){super.paintComponent(g);g.setColor(new Color(255,255,255,10));for(int y=8;y<getHeight();y+=18)for(int x=8;x<getWidth();x+=18)g.fillOval(x,y,2,2);}};root.setBackground(Theme.BG);root.add(buildSidebar(),BorderLayout.WEST);root.add(switcher,BorderLayout.CENTER);setContentPane(root);setGlassPane(toast);
        addScreen("Dashboard",new DashboardPanel(this,store,dataStore));addScreen("Inventory",new InventoryPanel(this,store,dataStore));addScreen("Customers",new CustomerPanel(this,store,dataStore));addScreen("Staff",new StaffPanel(this,store,dataStore));addScreen("Orders",new OrderPanel(this,store,dataStore));addScreen("Wishlist",new WishlistPanel(this,store,dataStore));addScreen("About / OOP",new AboutPanel(this,store,dataStore));
        navigate("Dashboard");
        addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){try{MainFrame.this.dataStore.saveAll(MainFrame.this.store);dispose();System.exit(0);}catch(IOException ex){int option=JOptionPane.showConfirmDialog(MainFrame.this,"Data could not be saved. Exit anyway?\n"+ex.getMessage(),"Save failed",JOptionPane.YES_NO_OPTION,JOptionPane.ERROR_MESSAGE);if(option==JOptionPane.YES_OPTION){dispose();System.exit(1);}}}});
        SwingUtilities.invokeLater(new Runnable(){public void run(){for(String notice:MainFrame.this.dataStore.consumeNotices())JOptionPane.showMessageDialog(MainFrame.this,notice,"Data status",JOptionPane.INFORMATION_MESSAGE);}});
    }
    private JPanel buildSidebar(){JPanel side=new JPanel();side.setPreferredSize(new Dimension(224,0));side.setBackground(new Color(17,21,42));side.setBorder(new EmptyBorder(24,16,18,16));side.setLayout(new BoxLayout(side,BoxLayout.Y_AXIS));
        JLabel brand=new JLabel("OTAKU NEXUS");brand.setForeground(Color.WHITE);brand.setFont(new Font("SansSerif",Font.BOLD,22));brand.setAlignmentX(Component.LEFT_ALIGNMENT);side.add(brand);JLabel sub=Theme.muted("STORE COMMAND CENTER");sub.setFont(new Font("SansSerif",Font.BOLD,10));sub.setAlignmentX(Component.LEFT_ALIGNMENT);side.add(sub);side.add(Box.createVerticalStrut(28));
        String[] names={"Dashboard","Inventory","Customers","Staff","Orders","Wishlist","About / OOP"};for(final String name:names){AnimeButton b=new AnimeButton(name,new Color(35,43,75));b.setHorizontalAlignment(SwingConstants.LEFT);b.setMaximumSize(new Dimension(Integer.MAX_VALUE,44));b.setAlignmentX(Component.LEFT_ALIGNMENT);b.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){navigate(name);}});side.add(b);side.add(Box.createVerticalStrut(9));nav.put(name,b);}side.add(Box.createVerticalGlue());JLabel foot=Theme.muted("Java Swing • File I/O • OOP");foot.setFont(new Font("SansSerif",Font.PLAIN,10));foot.setAlignmentX(Component.LEFT_ALIGNMENT);side.add(foot);return side;}
    private void addScreen(String name,StorePanel panel){panels.add(panel);switcher.addScreen(name,panel);}
    public void navigate(String name){for(Map.Entry<String,AnimeButton> e:nav.entrySet())e.getValue().setActive(e.getKey().equals(name));refreshAll();switcher.showScreen(name);}
    public void refreshAll(){for(StorePanel p:panels)p.refreshData();}
    public void showToast(String text){toast.showMessage(text);}
    private Image createAppIcon(){java.awt.image.BufferedImage b=new java.awt.image.BufferedImage(64,64,java.awt.image.BufferedImage.TYPE_INT_ARGB);Graphics2D g=b.createGraphics();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g.setPaint(new GradientPaint(0,0,Theme.PURPLE,64,64,Theme.RED));g.fillRoundRect(2,2,60,60,18,18);g.setColor(Color.WHITE);g.setFont(new Font("SansSerif",Font.BOLD,32));g.drawString("N",20,43);g.dispose();return b;}
}

class ToastGlass extends JComponent {
    private String text=""; private float alpha; private javax.swing.Timer timer;
    ToastGlass(){setOpaque(false);}
    void showMessage(String value){text="✓  "+value;alpha=1f;setVisible(true);if(timer!=null)timer.stop();timer=new javax.swing.Timer(35,new ActionListener(){int ticks;public void actionPerformed(ActionEvent e){ticks++;if(ticks>35)alpha-=.055f;repaint();if(alpha<=0){((javax.swing.Timer)e.getSource()).stop();setVisible(false);}}});timer.start();}
    protected void paintComponent(Graphics g){Graphics2D q=(Graphics2D)g.create();q.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);q.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,Math.max(0,alpha)));Font f=new Font("SansSerif",Font.BOLD,14);q.setFont(f);int w=q.getFontMetrics().stringWidth(text)+46,x=(getWidth()-w)/2,y=getHeight()-92;q.setColor(new Color(14,155,115));q.fillRoundRect(x,y,w,48,18,18);q.setColor(Color.WHITE);q.drawString(text,x+22,y+30);q.dispose();}
}
