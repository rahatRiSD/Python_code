package com.animestore.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Customer implements Serializable {
    private static final long serialVersionUID = 1L;
    private String customerId; private String name; private String contactNo; private String membershipType;
    private final List<String> wishlist = new ArrayList<String>();
    private final List<String> orderHistory = new ArrayList<String>();
    public Customer(String id, String name, String contactNo, String membershipType) {
        setCustomerId(id); setName(name); setContactNo(contactNo); setMembershipType(membershipType);
    }
    public String getCustomerId() { return customerId; }
    public void setCustomerId(String v) { customerId = required(v, "Customer ID"); }
    public String getName() { return name; }
    public void setName(String v) { name = required(v, "Customer name"); }
    public String getContactNo() { return contactNo; }
    public void setContactNo(String v) { contactNo = required(v, "Contact number"); }
    public String getMembershipType() { return membershipType; }
    public void setMembershipType(String v) { membershipType = required(v, "Membership type"); }
    public List<String> getWishlist() { return new ArrayList<String>(wishlist); }
    public List<String> getOrderHistory() { return new ArrayList<String>(orderHistory); }
    public void addToWishlist(String itemId) { if (!wishlist.contains(itemId)) wishlist.add(itemId); }
    public void removeFromWishlist(String itemId) { wishlist.remove(itemId); }
    public void purchaseItem(String orderId) { if (!orderHistory.contains(orderId)) orderHistory.add(orderId); }
    public void removeOrderFromHistory(String orderId) { orderHistory.remove(orderId); }
    private static String required(String v, String f) { if (v == null || v.trim().isEmpty()) throw new IllegalArgumentException(f + " is required."); return v.trim(); }
    @Override public String toString() { return name + " (" + customerId + ")"; }
}
