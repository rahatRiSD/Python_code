package com.animestore.model;

public class Anime extends Item {
    private static final long serialVersionUID = 1L;
    private String studio; private int episodeCount; private String genre;
    public Anime(String id, String title, double price, int stock, String studio, int episodes, String genre, String imagePath) {
        super(id, title, price, stock, imagePath); setStudio(studio); setEpisodeCount(episodes); setGenre(genre);
    }
    public String getStudio() { return studio; }
    public void setStudio(String value) { studio = required(value, "Studio"); }
    public int getEpisodeCount() { return episodeCount; }
    public void setEpisodeCount(int value) { if (value <= 0) throw new IllegalArgumentException("Episode count must be positive."); episodeCount = value; }
    public String getGenre() { return genre; }
    public void setGenre(String value) { genre = required(value, "Genre"); }
    @Override public String getDetails() { return "Studio: " + studio + " | Episodes: " + episodeCount + " | Genre: " + genre; }
    @Override public String getType() { return "Anime"; }
}
