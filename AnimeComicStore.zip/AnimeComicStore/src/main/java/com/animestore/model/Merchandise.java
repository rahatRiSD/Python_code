package com.animestore.model;

public class Merchandise extends Item {
    private static final long serialVersionUID = 1L;
    private String category; private String brand;
    public Merchandise(String id, String title, double price, int stock, String category, String brand, String imagePath) {
        super(id, title, price, stock, imagePath); setCategory(category); setBrand(brand);
    }
    public String getCategory() { return category; }
    public void setCategory(String value) { category = required(value, "Category"); }
    public String getBrand() { return brand; }
    public void setBrand(String value) { brand = required(value, "Brand"); }
    @Override public String getDetails() { return "Category: " + category + " | Brand: " + brand; }
    @Override public String getType() { return "Merchandise"; }
}
