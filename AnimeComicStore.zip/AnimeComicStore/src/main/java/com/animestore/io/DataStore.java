package com.animestore.io;

import com.animestore.model.*;
import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class DataStore {
    private final Path dataDir;
    private final List<String> notices = new ArrayList<String>();
    public DataStore() { this(Paths.get(System.getProperty("animestore.data", "data"))); }
    public DataStore(Path path) { dataDir = path; }

    public Store load() {
        Store store = new Store("Otaku Nexus", "Dhaka, Bangladesh");
        try { Files.createDirectories(dataDir); } catch (IOException e) { notices.add("The data folder could not be prepared: " + e.getMessage()); }
        boolean firstRun = !Files.exists(file("items.dat")) && !Files.exists(file("customers.dat")) && !Files.exists(file("staff.dat")) && !Files.exists(file("orders.dat"));
        if (firstRun) {
            seed(store);
            try { saveAll(store); notices.add("Welcome! Sample data was created for the first run."); }
            catch (IOException e) { notices.add("Sample data loaded, but could not be saved: " + e.getMessage()); }
            return store;
        }
        List<Item> items = readList("items.dat", Item.class);
        List<Customer> customers = readList("customers.dat", Customer.class);
        List<Staff> staff = readList("staff.dat", Staff.class);
        List<Order> orders = readList("orders.dat", Order.class);
        store.replaceData(items, customers, staff, orders);
        return store;
    }

    public synchronized void saveAll(Store store) throws IOException {
        Files.createDirectories(dataDir);
        writeAtomic("items.dat", new ArrayList<Item>(store.getInventory()));
        writeAtomic("customers.dat", new ArrayList<Customer>(store.getCustomers()));
        writeAtomic("staff.dat", new ArrayList<Staff>(store.getStaff()));
        writeAtomic("orders.dat", new ArrayList<Order>(store.getOrders()));
    }

    public List<String> consumeNotices() { List<String> copy = new ArrayList<String>(notices); notices.clear(); return copy; }
    private Path file(String name) { return dataDir.resolve(name); }

    private void writeAtomic(String name, Serializable data) throws IOException {
        Path target = file(name), temp = file(name + ".tmp"), backup = file(name + ".bak");
        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
            out.writeObject(data); out.flush();
        } finally { if (out != null) out.close(); }
        if (Files.exists(target)) Files.copy(target, backup, StandardCopyOption.REPLACE_EXISTING);
        try { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
        catch (AtomicMoveNotSupportedException e) { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING); }
    }

    @SuppressWarnings("unchecked")
    private <T> List<T> readList(String name, Class<T> type) {
        Path path = file(name);
        if (!Files.exists(path)) { notices.add(name + " was missing; an empty list was loaded safely."); return new ArrayList<T>(); }
        try {
            ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(Files.newInputStream(path)));
            Object raw;
            try { raw = in.readObject(); } finally { in.close(); }
            if (!(raw instanceof List)) throw new IOException("Unexpected file format");
            List<?> values = (List<?>) raw; List<T> result = new ArrayList<T>();
            for (Object value : values) {
                if (!type.isInstance(value)) throw new IOException("Unexpected record type");
                result.add((T) value);
            }
            return result;
        } catch (Exception primary) {
            Path backup = file(name + ".bak");
            if (Files.exists(backup)) {
                try {
                    ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(Files.newInputStream(backup)));
                    Object raw;
                    try { raw = in.readObject(); } finally { in.close(); }
                    if (raw instanceof List) {
                        List<T> result = new ArrayList<T>();
                        for (Object value : (List<?>) raw) if (type.isInstance(value)) result.add((T)value);
                        notices.add(name + " was damaged, so its last good backup was restored."); return result;
                    }
                } catch (Exception ignored) { }
            }
            notices.add(name + " could not be read safely; an empty list was used. Your other data is unchanged.");
            return new ArrayList<T>();
        }
    }

    private void seed(Store store) {
        try {
            store.addItem(new Anime("A001", "Skyblade Academy", 1299, 12, "Nova Studio", 24, "Action", ""));
            store.addItem(new Anime("A002", "Moonlit Alchemist", 999, 3, "Silver Frame", 12, "Fantasy", ""));
            store.addItem(new ComicBook("C001", "Neon Sentinel", 650, 9, "Indigo Ink", 1, "A. Rahman", ""));
            store.addItem(new ComicBook("C002", "Dhaka After Dark", 750, 2, "Panel Forge", 7, "N. Karim", ""));
            store.addItem(new Merchandise("M001", "Mecha Pilot Figure", 1890, 6, "Collectible Figure", "Starworks", ""));
            store.addItem(new Merchandise("M002", "Hero Guild Hoodie", 1490, 15, "Apparel", "Nexus Wear", ""));
            Customer c1 = new Customer("CU001", "Ayan Ahmed", "01710000001", "Gold"); c1.addToWishlist("A002");
            Customer c2 = new Customer("CU002", "Maya Noor", "01810000002", "Silver"); c2.addToWishlist("C001");
            store.addCustomer(c1); store.addCustomer(c2);
            store.addStaff(new Staff("ST001", "Rafi Hasan", "Manager"));
            store.addStaff(new Staff("ST002", "Nabila Islam", "Sales Associate"));
        } catch (Exception impossible) { throw new IllegalStateException(impossible); }
    }
}
