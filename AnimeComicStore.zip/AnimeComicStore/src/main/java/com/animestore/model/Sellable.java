package com.animestore.model;

import com.animestore.exception.OutOfStockException;

public interface Sellable {
    void sell() throws OutOfStockException;
}
